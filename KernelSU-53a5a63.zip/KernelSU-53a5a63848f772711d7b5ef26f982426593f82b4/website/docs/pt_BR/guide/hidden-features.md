# Recursos ocultos

## .ksurc

Por padrão, `/system/bin/sh` carrega `/system/etc/mkshrc`.

Você pode fazer su carregar um arquivo rc personalizado criando um arquivo `/data/adb/ksu/.ksurc`.
